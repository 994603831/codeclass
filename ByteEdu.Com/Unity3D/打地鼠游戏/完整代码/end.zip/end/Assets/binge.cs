﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class binge : MonoBehaviour
{

    public InputField strName, strpassword;
    private string lockName;


    IEnumerator GET(string url)
    {

        WWW www = new WWW(url);
        yield return www;

        if (www.error != null)
        {
            //GET请求失败   
            Debug.Log("error is :" + www.error);

        }
        else
        {
            //GET请求成功   
            Debug.Log("request ok : " + www.text);
            PlayerPrefs.SetString("account", lockName);
            // 切换场景,切换到打地鼠场景
            Application.LoadLevel(1);
        }
    }

    /// <summary>
    /// 1,获取输入框的数据：用户名/密码
    /// 2，获取数据进行逻辑判断
    /// 3，http ---》server 验证信息，
    /// 4,  http://127.0.0.1:8891/ByteEdu_Gophers?Protocol=1&Protocol2=1&Itype=1&LoginName=ByteEdu.Com&LoginPW=ByteEdu.Com
    /// </summary>
    public void Login()
    {
        Debug.Log("用户名："+strName.text);
        Debug.Log("密码：" + strpassword.text);
        lockName = strName.text;
        StartCoroutine(GET("http://local.golang.ltd:8891/ByteEdu_Gophers?Protocol=1&Protocol2=1&Itype=1&LoginName=ByteEdu.Com&LoginPW=ByteEdu.Com"));
        StartCoroutine(GET("http://local.golang.ltd:8891/ByteEdu_Gophers?Protocol=1&Protocol2=1&Itype=2&LoginName=ByteEdu.Com&LoginPW=ByteEdu.Com"));
    }
}